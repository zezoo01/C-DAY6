﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dayTask6
{
    struct Point
    {
        public int x, y;

        //Q1
        public Point()
        {
            x = y = 0;
        }
        //Q1and Q4
        public Point(int x, int y)
        {
            this.x = x;
            this.y = y;
        }

        //Q4
        public Point(int x)
        {
            this.x = x;
            y = 0;
        }

        //public override string ToString()
        //{
        //    return $"({x}, {y})";
        //}

        //Q5
        public override string ToString()
        {
            return $"X: {x}, Y: {y}";
        }

    }
}
