﻿using static System.Runtime.InteropServices.JavaScript.JSType;
using System.Diagnostics;
using System.Threading.Channels;

namespace dayTask6
{
    internal class Program
    {

        static void Main(string[] args)
        {
            #region Q1
            //Point p1 = new Point();
            //Console.WriteLine(p1.ToString());
            //Point p2 = new Point(3, 5);
            //Console.WriteLine(p2.ToString());
            ////Why can't a struct inherit from another struct or class in C#?
            ////- They are value types with stack-based memory allocation while inheritance requires reference semantics
            ////- Allowing inheritance would break their predictable and lightweight behavior.
            ////- It prevents potential issues with copying, boxing/unboxing, and runtime behavior.
            ////- Structs are optimized for simplicity and performance and inheritance would add unnecessary complexity. 
            #endregion
            #region Q2
            ////Access H
            //TypeA a = new TypeA();
            //Console.WriteLine(a.H);


            ////Access modifiers in C# determine the scope and visibility of class members such as fields,
            ////methods, properties, and nested classes
            ////- private: within the same class
            ////- private protected: within the same class, in subclasses within the same assembly
            ////- protected: within the same class, in subclasses
            ////- internel: within the same assembly
            ////- internal protected : in derived classes, within the same assembly
            ////- public: anywhere 
            #endregion
            #region Q3
            //Employee e = new Employee();
            //e.SetName("Ahmed");
            //Console.WriteLine(e.GetName());

            //e.EmpId = 7;
            //Console.WriteLine(e.EmpId);

            //e.Salary = 700000;
            //Console.WriteLine(e.Salary);


            // The Importance of Encapsulation in Software Design:
            //Encapsulation is important because it provides:
            //Data Protection: By making attributes private and providing methods to access them, it prevents unintended modifications.
            //Control Over Access: It allows control over how data is accessed and modified, including validation or applying rules when getting or setting data.
            //Maintainability: It allows internal changes without affecting the external code that interacts with the object.
            //Flexibility: It makes it easier to modify and extend the software without impacting external code.
            //Improved Debugging: It ensures that data modifications happen correctly, making it easier to debug issues.
            #endregion
            #region Q4
            //Point p1 = new Point(7);
            //Console.WriteLine(p1.ToString());
            //Point p2 = new Point(7, 3);
            //Console.WriteLine(p2.ToString());

            //Constructors in Structs:

            //Constructors in structs are special methods used to initialize a struct's fields when an instance is created. They can be:

            //Default Constructor: Automatically provided by the compiler to initialize fields to their default values.
            //Parameterized Constructors: Custom constructors that allow initialization with specific values.
            //Constructor Overloading: You can define multiple constructors with different parameter sets to create instances in various ways.
            //Unlike classes, structs cannot inherit from other types, and their constructors must explicitly initialize the fields.
            #endregion
            #region Q5
            //Point p = new Point(3, 7);
            //Console.WriteLine(p.ToString());
            #endregion

        }
    }
}
